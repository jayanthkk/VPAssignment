using System;
using Xunit;
using NumberToWordConverter;

namespace NumberToWordConverterXUnitTest
{
    public class NumberToWordConverterUnitTests
    {
        [Theory]
        [InlineData(999999999, "Nine Hundred Ninety Nine Million Nine Hundred Ninety Nine Thousand Nine Hundred Ninety Nine")]
        [InlineData(1, "One")]
        [InlineData(100, "One Hundred")]
        public void TestConversion(long inputNumber, string expectedOutPut)
        {
            string convertedValue = NumToWordConverter.SpellNumber(inputNumber);
            Assert.True(convertedValue == expectedOutPut);
        }
    }
}
