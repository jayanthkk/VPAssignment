﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace NumberToWordConverter
{
    class Program
    {
        private static bool Validate(string inPutNumber)
        {
            bool isInoutTextValid = false;
            isInoutTextValid = long.TryParse(inPutNumber, out long result);

            return isInoutTextValid;
        }

        static void Main(string[] args)
        {
            if (args!=null && args.Count() >0)
            {
                // set the value
                string numberToConvertToWord = args[0].Replace(",", "");
                // validate input

                if (Validate(numberToConvertToWord))
                {
                    var returnValue = NumToWordConverter.SpellNumber(Convert.ToInt64(numberToConvertToWord));
                    Console.WriteLine(returnValue);
                }
                else
                {
                    Console.WriteLine("Please input any interger no from 1 to 999,999,999");
                }
            }
            else
            {
                Console.WriteLine("Please provide some input!!!");
            }
           
            Console.Read();
        }
    }

   
}
